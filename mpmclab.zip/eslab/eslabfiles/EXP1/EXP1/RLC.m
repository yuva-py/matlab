clc;
clear;
close all;

R = 1;
L = 1;
C = 4;
Vs = 10;

h = 0.08;
t = 0:h:8;

v = zeros(size(t));
i = zeros(size(t));

v(1) = 0;
i(1) = 0;

for n = 1:length(t)-1

    k1_v = h*i(n)/C;
    k1_i = h*(Vs-R*i(n)-v(n))/L;

    k2_v = h*(i(n)+k1_i/2)/C;
    k2_i = h*(Vs-R*(i(n)+k1_i/2)-(v(n)+k1_v/2))/L;

    k3_v = h*(i(n)+k2_i/2)/C;
    k3_i = h*(Vs-R*(i(n)+k2_i/2)-(v(n)+k2_v/2))/L;

    k4_v = h*(i(n)+k3_i)/C;
    k4_i = h*(Vs-R*(i(n)+k3_i)-(v(n)+k3_v))/L;

    v(n+1) = v(n)+(k1_v+2*k2_v+2*k3_v+k4_v)/6;

    i(n+1) = i(n)+(k1_i+2*k2_i+2*k3_i+k4_i)/6;

end

figure(1);
plot(t,v,'m','LineWidth',1.5);
grid on;
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Voltage Across Capacitor for Series RLC Circuit');

figure(2);
plot(t,i,'b','LineWidth',1.5);
grid on;
xlabel('Time (s)');
ylabel('Current (A)');
title('Current in Series RLC Circuit');