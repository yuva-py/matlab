clc;
clear;
close all;

R = 1;
L = 10;
V = 10;
h = 0.5;
t = 0: h: 50;

i = zeros(size(t));
vl = zeros(size(t));

i(1) = 0;
vl(1) = V;

for n = 1:length(t)-1

    k1 = h * (V - R*i(n))/L;
    k2 = h * (V - R*(i(n)+k1/2))/L;
    k3 = h * (V - R*(i(n)+k2/2))/L;
    k4 = h * (V - R*(i(n)+k3))/L;

    i(n+1) = i(n) + (k1+2*k2+2*k3+k4)/6;

    vl(n+1) = V - R*i(n+1);

end

figure(1);
plot(t,i,'b','LineWidth',1.5);
grid on;
xlabel('Time (s)');
ylabel('Current (A)');
title('Current in RL Circuit');

figure(2);
plot(t,vl,'r','LineWidth',1.5);
grid on;
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Voltage Across Inductor');