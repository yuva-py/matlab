clc;
clear;
close all;

R = 10;
C = 0.0001;
V = 10;
h = 0.0005;

t = 0:h:0.05;
vc = zeros(size(t));
ic = zeros(size(t));

vc(1) = 0;

for n = 1:length(t)-1

    k1 = h*(V-vc(n))/(R*C);
    k2 = h*(V-(vc(n)+k1/2))/(R*C);
    k3 = h*(V-(vc(n)+k2/2))/(R*C);
    k4 = h*(V-(vc(n)+k3))/(R*C);

    vc(n+1) = vc(n)+(k1+2*k2+2*k3+k4)/6;

    ic(n+1) = (V-vc(n+1))/R;

end

ic(1) = V/R;

figure(1);
plot(t,vc,'r','LineWidth',1.5);
grid on;
xlabel('Time (s)');
ylabel('Voltage (V)');
title('Voltage Across Capacitor');

figure(2);
plot(t,ic,'b','LineWidth',1.5);
grid on;
xlabel('Time (s)');
ylabel('Current (A)');
title('Current in RC Circuit');