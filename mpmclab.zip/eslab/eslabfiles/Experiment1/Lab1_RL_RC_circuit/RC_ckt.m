clear all;
clc;
R=10;C=0.001;V=2;vc0=0;
tspan=[0 0.1]
[t vc]=ode45(@(t,vc)(V-vc)/(R*C),tspan,vc0);
figure;
plot(t,vc,'b','LineWidth',2);
xlabel('Time(sec)');
ylabel('Voltage vc volts');
title('Voltage across capacitor in RC circuit');