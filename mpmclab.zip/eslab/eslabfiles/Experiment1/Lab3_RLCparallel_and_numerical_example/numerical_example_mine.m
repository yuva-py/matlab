clear all; clc; close all;
h=0.5;t0=0;tf=2;i0=0.5;
t=t0:h:tf;
N=length(t);
f=@(t,i)(i-power(t,2)+1);
i=zeros(1,N);
i(1)=i0;
for j=1:(N-1)
    k1=f(t(j),i(j));   
    k2=f(t(j)+0.5*h,i(j)+0.5*h*k1);   
    k3=f(t(j)+0.5*h,i(j)+0.5*h*k2);   
    k4=f(t(j)+h,i(j)+h*k3);
    i(j+1)=i(j)+(h/6)*(k1+2*k2+2*k3+k4);   
end  
plot(t,i);
hold on;
i_exact=zeros(1,N);
i_exact(1)=i0;
tspan=[t0 tf];
[t i_exact]=ode45(f,tspan,i0);
plot(t,i_exact,'m');