clc;clear;close all;
f=@(t,y)y-t.^2+1;
y_exact=@(t)(t+1).^2-0.5*exp(t);
h_values=[0.5 0.2 0.05];
figure;
for k=1:length(h_values)
h=h_values(k);N=round(2/h);
t=0:h:2;y=zeros(size(t));
y(1)=0.5;
for i=1:N
k1=f(t(i),y(i));
k2=f(t(i)+h/2,y(i)+h*k1/2);
k3=f(t(i)+h/2,y(i)+h*k2/2);
k4=f(t(i)+h,y(i)+h*k3);
y(i+1)=y(i)+h*(k1+2*k2+2*k3+k4)/6;
end
ye=y_exact(t);error=abs(ye-y);
fprintf('============================================================\n');
fprintf('RK4 RESULTS FOR h = %.2f\n',h);
fprintf('============================================================\n');
fprintf('%8s %20s %20s %20s\n','t_i','Exact y(t)','Numerical y','Error |y-y_num|');
fprintf('------------------------------------------------------------\n');
for i=1:length(t)
fprintf('%8.2f %20.10f %20.10f %20.10f\n',t(i),ye(i),y(i),error(i));
end
fprintf('------------------------------------------------------------\n');
fprintf('Maximum Error = %.10f\n',max(error));
subplot(3,1,k);
plot(t,ye,'k-','LineWidth',2);
hold on;
plot(t,y,'ro--','LineWidth',1.5,'MarkerFaceColor','r');
grid on;
xlabel('t');ylabel('y(t)');
title(['RK4 Solution (h = ',num2str(h),')']);
legend('Exact','RK4','Location','northwest');end