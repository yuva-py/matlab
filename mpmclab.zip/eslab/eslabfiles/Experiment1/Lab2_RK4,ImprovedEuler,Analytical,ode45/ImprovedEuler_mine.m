clear all;clc;close all;
V=2;R=10;i0=0;L=0.01;
f=@(t,i)(V-i*R)/L;
t0=0;tf=0.1;h=0.001;
t=t0:h:tf;N=length(t);
i=zeros(1,N);i(1)=i0;
for j=1:(N-1)
k1=f(t(j),i(j));
k2=f(t(j)+h,i(j)+h*k1);
i(j+1)=i(j)+(h/2)*(k1+k2);
end
figure;
plot(t,i,'r--','LineWidth',2);
hold on;
i1=zeros(1,N);
for j=1:(N-1)
k1=f(t(j),i1(j));
k2=f(t(j)+0.5*h,i1(j)+0.5*h*k1);
k3=f(t(j)+0.5*h,i1(j)+0.5*h*k2);
k4=f(t(j)+h,i1(j)+h*k3);
i1(j+1)=i1(j)+(h/6)*(k1+2*k2+2*k3+k4);
end
plot(t,i1,'b-.','LineWidth',2);
hold on;
tspan=[0 0.1];
[t,i2]=ode45(@(t,i2)(V-i2*R)/L,tspan,i0);
plot(t,i2,'m:','LineWidth',3);
hold on;
i3=(V/R)*(1-exp(-(R*t)/L));
plot(t,i3,'g-','LineWidth',2);
hold on;
legend('Improved Euler','RK4 Method','ode45','Analytical','Location','southeast');
xlabel('Time (s)');ylabel('Current (A)');
title('RL Circuit Response');
hold off;