%LQRI Controller Design
clc;clear;close all;

%Plant Matrices 
A=[0,375;
    -3409.1,-1515.2];
B=[125; 0];
C=[1,0];
D=0;
%Augmented matrices
Aa=[A,zeros(2,1);-C,0];
Ba=[B;0];

%Qa(3x3) and Ra(1x1)
Qa=diag([10,100,500]);
Ra=1;

K_augmented=lqr(Aa,Ba,Qa,Ra);

k22=K_augmented(1:2)
k11=-K_augmented(3)

fprintf('--- Your Simulink Block Values ---\n');
fprintf('Lower Feedback Gain Block (Matrix Multiplication):\n');
disp(k22);
fprintf('Upper Integral Gain Block (Scalar Multiplication):\n');
disp(k11);